#!/bin/bash
# Deployment script for Hetzner server

echo "╔════════════════════════════════════════════════════════╗"
echo "║  492-Energy-Defense Deployment Script                 ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root (or use sudo)"
    exit 1
fi

echo "[1/6] Updating system packages..."
apt-get update -qq
apt-get upgrade -y -qq

echo "[2/6] Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    rm get-docker.sh
    systemctl enable docker
    systemctl start docker
    echo "✓ Docker installed"
else
    echo "✓ Docker already installed"
fi

echo "[3/6] Installing Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
    apt-get install -y docker-compose-plugin
    echo "✓ Docker Compose installed"
else
    echo "✓ Docker Compose already installed"
fi

echo "[4/6] Setting up firewall..."
apt-get install -y ufw
ufw --force enable
ufw allow 22/tcp     # SSH
ufw allow 8000/tcp   # Agent API
ufw allow 3000/tcp   # Dashboard
ufw allow 11434/tcp  # Ollama (optional)
echo "✓ Firewall configured"

echo "[5/6] Setting up environment..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✓ Created .env file"
fi

echo "[6/6] Starting services..."
docker compose down 2>/dev/null || true
docker compose up -d

echo ""
echo "════════════════════════════════════════════════════════"
echo "Deployment in progress..."
echo "════════════════════════════════════════════════════════"
echo ""
echo "Waiting for services to initialize (this may take 2-3 minutes)..."
sleep 10

echo ""
echo "Monitoring Qwen model download..."
docker logs -f ollama-init 2>&1 &
LOGS_PID=$!

# Wait for model to be ready (max 5 minutes)
COUNTER=0
while [ $COUNTER -lt 60 ]; do
    if docker logs ollama-init 2>&1 | grep -q "Qwen model ready"; then
        kill $LOGS_PID 2>/dev/null || true
        echo ""
        echo "✓ Qwen model downloaded successfully"
        break
    fi
    sleep 5
    COUNTER=$((COUNTER + 1))
done

if [ $COUNTER -eq 60 ]; then
    echo "⚠ Model download taking longer than expected"
    echo "  Check logs with: docker logs ollama-init"
fi

echo ""
echo "Checking service status..."
docker ps --format "table {{.Names}}\t{{.Status}}" | grep -E "NAME|cyber|ollama"

echo ""
echo "════════════════════════════════════════════════════════"
echo "✅ Deployment Complete!"
echo "════════════════════════════════════════════════════════"
echo ""
echo "Your services are now running:"
echo ""
echo "  • Dashboard:  http://$(hostname -I | awk '{print $1}'):3000"
echo "  • Agent API:  http://$(hostname -I | awk '{print $1}'):8000"
echo "  • API Docs:   http://$(hostname -I | awk '{print $1}'):8000/docs"
echo ""
echo "Useful commands:"
echo "  • View logs:         docker compose logs -f"
echo "  • Check status:      docker ps"
echo "  • Stop services:     docker compose down"
echo "  • Restart services:  docker compose restart"
echo "  • Test model:        ./check-qwen-model.sh"
echo ""
echo "If you encounter scoring issues with Qwen 0.5B:"
echo "  • Run: ./apply-fix.sh"
echo "  • See: FIX_QWEN_SCORING_ISSUE.md"
echo ""
