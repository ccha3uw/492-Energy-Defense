"""Backend package for cybersecurity event generation and analysis."""
