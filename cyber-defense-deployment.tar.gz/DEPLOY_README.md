# Deployment Package for Hetzner

## Quick Deployment Steps

### 1. Upload to Hetzner Server

```bash
# On your local machine
scp cyber-defense-deployment.tar.gz root@YOUR_SERVER_IP:/root/
```

### 2. Extract and Deploy

```bash
# SSH into your Hetzner server
ssh root@YOUR_SERVER_IP

# Extract the package
cd /root
tar -xzf cyber-defense-deployment.tar.gz
cd cyber-defense-package

# Run deployment script
./deploy.sh
```

That's it! The script will:
- ✅ Install Docker and Docker Compose
- ✅ Configure firewall
- ✅ Start all services
- ✅ Download Qwen model
- ✅ Set up the dashboard

### 3. Access Your Services

After deployment completes (2-3 minutes):

- **Dashboard**: http://YOUR_SERVER_IP:3000
- **Agent API**: http://YOUR_SERVER_IP:8000
- **API Docs**: http://YOUR_SERVER_IP:8000/docs

## Server Requirements

### Minimum (Budget)
- **RAM**: 8GB
- **CPU**: 2 vCPUs
- **Storage**: 20GB
- **Cost**: ~€8-15/month

Recommended Hetzner: **CPX21** (3 vCPU, 8GB RAM)

### Recommended (Better Performance)
- **RAM**: 16GB
- **CPU**: 4 vCPUs
- **Storage**: 40GB
- **Cost**: ~€30/month

Recommended Hetzner: **CPX31** (4 vCPU, 16GB RAM)

## Troubleshooting

### Model Not Loading
```bash
# Check logs
docker logs ollama-init

# Manually pull model
docker exec ollama-qwen ollama pull qwen2.5:0.5b
```

### Services Not Starting
```bash
# Check all logs
docker compose logs

# Restart everything
docker compose down
docker compose up -d
```

### Firewall Issues
```bash
# Check firewall status
ufw status

# Open required ports
ufw allow 8000/tcp
ufw allow 3000/tcp
```

### Qwen Model Scoring Incorrectly
The 0.5B model may give inaccurate scores. Fix options:

```bash
# Option 1: Switch to rule-based (most accurate)
./apply-fix.sh  # Choose option 1

# Option 2: Upgrade to Qwen 1.5B (better AI)
./apply-fix.sh  # Choose option 2
```

See `FIX_QWEN_SCORING_ISSUE.md` for details.

## Manual Deployment (Alternative)

If the deploy.sh script doesn't work, you can manually:

```bash
# Install Docker
curl -fsSL https://get.docker.com | sh

# Install Docker Compose
apt-get install docker-compose-plugin

# Configure firewall
ufw allow 22/tcp
ufw allow 8000/tcp
ufw allow 3000/tcp

# Start services
docker compose up -d

# Watch model download
docker logs -f ollama-init
```

## Configuration

### Change Model
Edit `docker-compose.yml`:
```yaml
environment:
  - OLLAMA_MODEL=qwen2.5:1.5b  # Change to 1.5b or 3b
```

### Disable LLM (Use Rule-Based)
Edit `docker-compose.yml`:
```yaml
environment:
  - USE_LLM=false  # Use accurate rule-based scoring
```

### Change Database Password
Edit `.env` or `docker-compose.yml`:
```yaml
environment:
  POSTGRES_PASSWORD: your_secure_password
```

## Support Files Included

- `deploy.sh` - Automated deployment script
- `check-qwen-model.sh` - Verify model is loaded
- `apply-fix.sh` - Fix scoring issues
- `test-llm-mode.sh` - Test the system
- `FIX_QWEN_SCORING_ISSUE.md` - Detailed troubleshooting

## Next Steps After Deployment

1. **Test the system**:
   ```bash
   ./check-qwen-model.sh
   ```

2. **Access the dashboard**:
   Open http://YOUR_SERVER_IP:3000 in browser

3. **Test the API**:
   ```bash
   curl http://localhost:8000/health | jq
   ```

4. **Monitor logs**:
   ```bash
   docker compose logs -f
   ```

---

**Questions? Check the main README.md or FIX_QWEN_SCORING_ISSUE.md**
