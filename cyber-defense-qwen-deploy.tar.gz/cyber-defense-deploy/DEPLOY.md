# Quick Deployment to Hetzner

## On Your Local Machine

1. Upload this package to your server:
```bash
scp cyber-defense-qwen-deploy.tar.gz root@YOUR_SERVER_IP:/root/
```

## On Hetzner Server (as root)

1. Extract the package:
```bash
cd /root
tar -xzf cyber-defense-qwen-deploy.tar.gz
cd cyber-defense-deploy
```

2. Install Docker (if not already installed):
```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh
```

3. Start the system:
```bash
chmod +x *.sh
docker-compose up -d
```

4. Watch the model download:
```bash
docker logs -f ollama-init
# Wait for "Qwen model ready!"
```

5. Test it works:
```bash
./check-qwen-model.sh
```

## Access the System

- **Dashboard**: http://YOUR_SERVER_IP:3000
- **API**: http://YOUR_SERVER_IP:8000
- **API Docs**: http://YOUR_SERVER_IP:8000/docs

## Configure Firewall (Optional but Recommended)

```bash
ufw allow 22/tcp    # SSH
ufw allow 3000/tcp  # Dashboard
ufw allow 8000/tcp  # API
ufw enable
```

## Troubleshooting

If issues occur:
```bash
./troubleshoot.sh
```

To use rule-based mode (no LLM, more reliable):
```bash
./apply-fix.sh
# Choose option 1
```
