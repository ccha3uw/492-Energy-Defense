#!/bin/bash
# Quick setup script for Hetzner server

echo "╔════════════════════════════════════════════════════════╗"
echo "║  492-Energy-Defense - Hetzner Setup                   ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Please run as root"
    exit 1
fi

echo "📦 Step 1: Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    rm get-docker.sh
    echo "✅ Docker installed"
else
    echo "✅ Docker already installed"
fi

echo ""
echo "🔧 Step 2: Installing Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
    # Install docker-compose
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    echo "✅ Docker Compose installed"
else
    echo "✅ Docker Compose already installed"
fi

echo ""
echo "📝 Step 3: Creating environment file..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✅ Created .env file"
else
    echo "✅ .env file already exists"
fi

echo ""
echo "🚀 Step 4: Starting services..."
chmod +x *.sh
docker-compose up -d

echo ""
echo "⏳ Step 5: Waiting for model download..."
echo "   (This will take 1-2 minutes)"
sleep 15

echo ""
echo "📊 Checking status..."
docker-compose ps

echo ""
echo "╔════════════════════════════════════════════════════════╗"
echo "║  🎉 Setup Complete!                                   ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""
echo "Your services are starting up..."
echo ""
echo "🌐 Access Points:"
echo "   • Dashboard: http://$(hostname -I | awk '{print $1}'):3000"
echo "   • API:       http://$(hostname -I | awk '{print $1}'):8000"
echo "   • API Docs:  http://$(hostname -I | awk '{print $1}'):8000/docs"
echo ""
echo "📝 Next Steps:"
echo "   1. Wait 2-3 minutes for initialization"
echo "   2. Check model status: ./check-qwen-model.sh"
echo "   3. Monitor logs: docker-compose logs -f"
echo ""
echo "🔒 Security Recommendations:"
echo "   • Configure firewall: ufw allow 22,3000,8000/tcp && ufw enable"
echo "   • Change database password in docker-compose.yml"
echo "   • Use HTTPS in production"
echo ""
