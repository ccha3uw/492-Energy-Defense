#!/bin/bash
# Run this script on your Hetzner server

echo "════════════════════════════════════════════════════════"
echo "  492-Energy-Defense - Server Setup"
echo "════════════════════════════════════════════════════════"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Please run as root (or use sudo)"
    exit 1
fi

echo "📦 Installing dependencies..."

# Update system
apt-get update -qq

# Install Docker if not present
if ! command -v docker &> /dev/null; then
    echo "  Installing Docker..."
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
    echo "  ✓ Docker installed"
else
    echo "  ✓ Docker already installed"
fi

# Install Docker Compose if not present
if ! command -v docker-compose &> /dev/null; then
    echo "  Installing Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    echo "  ✓ Docker Compose installed"
else
    echo "  ✓ Docker Compose already installed"
fi

# Install useful tools
apt-get install -y jq curl wget htop nano -qq

echo ""
echo "🚀 Starting application..."
cd "$(dirname "$0")"

# Make scripts executable
chmod +x *.sh 2>/dev/null || true

# Start services
docker-compose up -d

echo ""
echo "⏳ Waiting for services to initialize..."
echo "   (This will take 1-2 minutes for Qwen model download)"
echo ""

# Wait for Ollama init
sleep 15
echo "📥 Downloading Qwen model..."
docker logs ollama-init 2>&1 | tail -5

echo ""
echo "Waiting for agent to be ready..."
sleep 20

# Try to connect to agent
for i in {1..10}; do
    if curl -f -s http://localhost:8000/health > /dev/null 2>&1; then
        echo "✅ Agent is ready!"
        break
    fi
    echo "  Waiting... ($i/10)"
    sleep 3
done

echo ""
echo "════════════════════════════════════════════════════════"
echo "  ✅ Deployment Complete!"
echo "════════════════════════════════════════════════════════"
echo ""
echo "📊 Services:"
echo "   • Agent API:    http://localhost:8000"
echo "   • API Docs:     http://localhost:8000/docs"
echo "   • Dashboard:    http://localhost:3000"
echo "   • Database:     localhost:5432"
echo ""
echo "🔍 Check status:"
echo "   docker-compose ps"
echo ""
echo "📝 View logs:"
echo "   docker-compose logs -f"
echo ""
echo "🔧 Quick fix (if scoring issues):"
echo "   ./apply-fix.sh"
echo ""
echo "🌐 To access from outside the server:"
echo "   1. Configure firewall: ufw allow 8000/tcp"
echo "   2. Access via: http://YOUR_SERVER_IP:8000"
echo ""
