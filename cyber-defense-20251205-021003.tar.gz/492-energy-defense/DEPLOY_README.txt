╔══════════════════════════════════════════════════════════╗
║  492-ENERGY-DEFENSE - DEPLOYMENT PACKAGE                ║
╚══════════════════════════════════════════════════════════╝

QUICK START (On Hetzner Server):

1. Upload this folder to your server:
   - Use scp, sftp, or web upload
   - Or extract the tar.gz on the server

2. SSH into your server:
   ssh root@YOUR_SERVER_IP

3. Navigate to the folder:
   cd 492-energy-defense

4. Run the deployment script:
   chmod +x deploy-on-server.sh
   ./deploy-on-server.sh

5. Wait 1-2 minutes for setup to complete

6. Access the services:
   • Agent API: http://YOUR_SERVER_IP:8000
   • Dashboard: http://YOUR_SERVER_IP:3000

══════════════════════════════════════════════════════════

WHAT IT DOES:

✓ Installs Docker and Docker Compose
✓ Sets up all services
✓ Downloads Qwen AI model (~400MB)
✓ Starts the cybersecurity agent
✓ Initializes database

══════════════════════════════════════════════════════════

REQUIREMENTS:

• Ubuntu 20.04+ or Debian 11+
• 4GB+ RAM (recommended: 8GB)
• 20GB+ disk space
• Root access

══════════════════════════════════════════════════════════

USEFUL COMMANDS:

Check status:
  docker-compose ps

View logs:
  docker-compose logs -f

Stop services:
  docker-compose down

Restart:
  docker-compose restart

Fix scoring issues:
  ./apply-fix.sh

══════════════════════════════════════════════════════════

FIREWALL SETUP (Optional):

To access from your local machine:

  ufw allow 22/tcp    # SSH
  ufw allow 8000/tcp  # Agent API
  ufw allow 3000/tcp  # Dashboard
  ufw enable

══════════════════════════════════════════════════════════

For full documentation, see README.md

Support: Check logs with 'docker-compose logs'
