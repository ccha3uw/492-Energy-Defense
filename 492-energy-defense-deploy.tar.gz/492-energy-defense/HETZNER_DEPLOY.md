# Quick Deployment to Hetzner

## Step 1: Create Server

1. Go to https://console.hetzner.cloud/
2. Create new server:
   - **Image**: Ubuntu 22.04 LTS
   - **Type**: CPX21 (3 vCPU, 8GB RAM) - €15/month minimum
   - **Location**: Closest to you
   - **Add SSH Key** (or use password)
3. Copy the server IP address

## Step 2: Upload Package

From your local machine:

```bash
# Upload the deployment package
scp 492-energy-defense-deploy.tar.gz root@YOUR_SERVER_IP:/root/

# Or if you have the extracted directory
scp -r 492-energy-defense root@YOUR_SERVER_IP:/root/
```

## Step 3: Deploy

SSH into your server:

```bash
ssh root@YOUR_SERVER_IP
```

Then run:

```bash
# If you uploaded the tar.gz
cd /root
tar -xzf 492-energy-defense-deploy.tar.gz
cd 492-energy-defense

# Run deployment script
chmod +x deploy-hetzner.sh
./deploy-hetzner.sh
```

That's it! The script will:
- Install Docker & Docker Compose
- Configure firewall
- Download Qwen model
- Start all services

## Step 4: Access Your System

- **Dashboard**: http://YOUR_SERVER_IP:3000
- **API**: http://YOUR_SERVER_IP:8000
- **API Docs**: http://YOUR_SERVER_IP:8000/docs

## Troubleshooting

### Check if services are running
```bash
docker-compose ps
```

### View logs
```bash
docker-compose logs -f
```

### Check Qwen model
```bash
docker exec ollama-qwen ollama list
```

### Restart services
```bash
docker-compose restart
```

### Fresh start
```bash
docker-compose down
docker-compose up -d
```

## Security Notes

**For production, you should:**
1. Change default passwords in `.env`
2. Set up a domain with SSL/TLS
3. Restrict database port (5432) in firewall
4. Create a non-root user
5. Set up automatic backups

## Resource Requirements

- **Minimum**: CPX21 (8GB RAM, 3 vCPU) - €15/month
- **Recommended**: CPX31 (16GB RAM, 4 vCPU) - €30/month

The Qwen 2.5 0.5B model needs ~2-4GB RAM.

## Support

View logs if something goes wrong:
```bash
docker-compose logs agent
docker-compose logs ollama-qwen
docker-compose logs backend
```
