#!/bin/bash
# Hetzner deployment script - Run as root

set -e

echo "╔════════════════════════════════════════════════════════╗"
echo "║  492-Energy-Defense - Hetzner Deployment              ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
   echo -e "${RED}Please run as root (or use sudo)${NC}"
   exit 1
fi

echo -e "${YELLOW}[1/6] Updating system...${NC}"
apt-get update -qq
apt-get upgrade -y -qq

echo -e "${YELLOW}[2/6] Installing Docker...${NC}"
if ! command -v docker &> /dev/null; then
    # Install Docker
    apt-get install -y -qq apt-transport-https ca-certificates curl software-properties-common
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | apt-key add -
    add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
    apt-get update -qq
    apt-get install -y -qq docker-ce docker-ce-cli containerd.io
    echo -e "${GREEN}✓ Docker installed${NC}"
else
    echo -e "${GREEN}✓ Docker already installed${NC}"
fi

echo -e "${YELLOW}[3/6] Installing Docker Compose...${NC}"
if ! command -v docker-compose &> /dev/null; then
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    echo -e "${GREEN}✓ Docker Compose installed${NC}"
else
    echo -e "${GREEN}✓ Docker Compose already installed${NC}"
fi

echo -e "${YELLOW}[4/6] Starting Docker service...${NC}"
systemctl start docker
systemctl enable docker
echo -e "${GREEN}✓ Docker service running${NC}"

echo -e "${YELLOW}[5/6] Configuring firewall...${NC}"
# Install ufw if not present
if ! command -v ufw &> /dev/null; then
    apt-get install -y -qq ufw
fi

# Configure firewall
ufw --force enable
ufw allow 22/tcp    # SSH
ufw allow 8000/tcp  # Agent API
ufw allow 3000/tcp  # Dashboard
ufw allow 5432/tcp  # PostgreSQL (optional, for external access)
echo -e "${GREEN}✓ Firewall configured${NC}"

echo -e "${YELLOW}[6/6] Starting application...${NC}"
cd /root/492-energy-defense

# Build and start services
docker-compose build
docker-compose up -d

echo ""
echo "Waiting for services to initialize..."
sleep 15

# Wait for Qwen model download
echo "Downloading Qwen model (1-2 minutes)..."
docker logs -f ollama-init &
LOGS_PID=$!
sleep 60
kill $LOGS_PID 2>/dev/null || true

echo ""
echo "════════════════════════════════════════════════════════"
echo -e "${GREEN}✅ Deployment Complete!${NC}"
echo "════════════════════════════════════════════════════════"
echo ""
echo "Your services are now running:"
echo ""
echo "  📊 Dashboard:    http://$(curl -s ifconfig.me):3000"
echo "  🤖 Agent API:    http://$(curl -s ifconfig.me):8000"
echo "  📚 API Docs:     http://$(curl -s ifconfig.me):8000/docs"
echo "  🗄️  Database:     $(curl -s ifconfig.me):5432"
echo ""
echo "Useful commands:"
echo "  View logs:       docker-compose logs -f"
echo "  Check status:    docker-compose ps"
echo "  Stop services:   docker-compose down"
echo "  Restart:         docker-compose restart"
echo ""
echo "Check model status:"
echo "  docker exec ollama-qwen ollama list"
echo ""
echo "Test the agent:"
echo "  curl http://localhost:8000/health | jq"
echo ""

